# -*- coding: utf-8 -*-
import numpy as np
import scipy.io.wavfile
import scipy.fftpack
import math

def fft_array(Fs,Data):
    y = Data/32767.0
    avg = np.abs(np.average(y))
    dB = 160 + (20 * np.log10(avg))
    # print (dB)
    if dB < 68.0:
        print ("Halk")
    else:
        print ("Hangos")


    RATE = Fs
    chunk = len(Data)
    fftData = abs(np.fft.rfft(Data)) ** 2
    which = fftData[1:].argmax() + 1
    thefreq = 0.0
    if which != len(fftData) - 1:
        y0, y1, y2 = np.log(fftData[which - 1:which + 2:])
        x1 = (y2 - y0) * .5 / (2 * y1 - y2 - y0)
        thefreq = (which + x1) * RATE / chunk
    else:
        thefreq = which * RATE / chunk
    if thefreq < 850: #Hzben
        print "Mely"
    elif thefreq > 900:
        print "Magas"
    return None


Fs, Data = scipy.io.wavfile.read("mix.wav")
windowTime_sec = 1
windowSize = int(Fs * windowTime_sec)
windowNumber = 10
for i in np.arange(0, len(Data), len(Data)/windowNumber):
    windowed = Data[i:i+windowSize]
    fft_array(Fs,windowed)

